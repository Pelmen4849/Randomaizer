package com.example.tetris001;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    TextView textView;
    TextView textView2;
    TextView textView3;
    EditText editTextText2;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView3 = findViewById(R.id.textView3);
        editText = findViewById(R.id.editTextText);
        editTextText2 = findViewById(R.id.editTextText2);
        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                int num1 = Integer.parseInt(editText.getText().toString());
                int num2 = Integer.parseInt(editTextText2.getText().toString());
                Random rn = new Random();
                int randomNum = rn.nextInt(num2 - num1 + 1) + num1;

                int randomNum1 = rn.nextInt(num2 - num1 + 1) + num1;
                int randomNum2 = rn.nextInt(num2 - num1 + 1) + num1;
                textView3.setText(String.valueOf(randomNum));
                textView.setText(String.valueOf(randomNum1));
                textView2.setText(String.valueOf(randomNum2));
               

            }
        });

    }
}